function outputStruct = pack(varargin)
%PACK Universal packer function for structural arrays
%   uses as fieldnames the input names with which this function has been
%   called
  nargs = nargin;
  for i=1:nargs
    outputStruct.(inputname(i)) = varargin{i};
  end
end

