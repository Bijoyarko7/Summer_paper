%% dynamicLafferCurve.m
% This script determines the dynamic Laffer curve and saves the results
% into the mat file with name defined in 'export_filename'. Saved outputs
% are used in plotLafferCurve.m and plotLafferCurveComparison.m.
% NOTE: this script requires parameter struct arrays 'param' and 'algParam'
% in the workspace. RUN mainScript.m OR ONE OF THE SCRIPTS
% mainScript_robustnessX.m (X=1,2,3) FIRST BEFORE EXECUTING THIS SCRIPT!
%% script settings parameters

policyGridAdjBondGrowth = linspace(-0.05,0.3,130)';
export_filename = 'lafferCurve_robustness3';
%names used for export_filename:
% - 'lafferCurve_baseline' (after running mainScript.m)
% - 'lafferCurve_robustness1' (after running mainScript_robustness1.m)
% - 'lafferCurve_robustness2' (after running mainScript_robustness2.m)
% - 'lafferCurve_robustness3' (after running mainScript_robustness3.m)

%% alternative scenarios
adjBondGrowth0Baseline = params.adjBondGrowth0;
meanBubbleMining = NaN(size(policyGridAdjBondGrowth));
meanDeficitOutputRatio = NaN(size(policyGridAdjBondGrowth));
for i=1:numel(policyGridAdjBondGrowth)
  params.adjBondGrowth0 = policyGridAdjBondGrowth(i);
  [moments,modelSolution] = computeMomentsFromParams(params,algParams);
  meanBubbleMining(i) = moments.meanAdjBondGrowth;
  meanDeficitOutputRatio(i) = -moments.meanSurplusOutputRatio;
end

params.adjBondGrowth0 = adjBondGrowth0Baseline;

%% steady-state Laffer curve
% (from closed-form solution)

[sigmaI0,chi,gamma,rho,phi,a0,g0] = ...
  aux.unpack(params,'sigma','chi','gamma','rho','phi','a0','g0'); %retrieve model parameters

deficitOutputRatioSteadyState = meanBubbleMining.*(sqrt(gamma)*chi*sigmaI0 - sqrt(rho + meanBubbleMining)).*(1 + phi*(a0-g0))./(sqrt(rho + meanBubbleMining) + phi*rho*sqrt(gamma)*chi*sigmaI0)./a0;
deficitOutputRatioSteadyState(meanBubbleMining>0) = max(deficitOutputRatioSteadyState(meanBubbleMining>0),0);

%% save results
save(export_filename,'params','policyGridAdjBondGrowth','meanBubbleMining','meanDeficitOutputRatio','deficitOutputRatioSteadyState');