function capitalGrowth = investmentTechnology(investmentRate,phi,iota0)
%INVESTMENTTECHNOLOGY Encodes the \Phi function in the model
  if phi == 0
    capitalGrowth = investmentRate;
  else
    capitalGrowth = iota0 + log(1 + phi*(investmentRate-iota0))./phi;
  end
end

