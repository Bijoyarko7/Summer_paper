function [a0,g0,rho,adjBondGrowth0,iota0] = preCalibration(debtGdp,capitalGdp,investmentGdp,govSpendingGdp,surplusGdp,invRate,phi)
%PRECALIBRATION maps a number of steady-state targets into parameters consistent with them
%   This is simply a transformation of the parameter space. The
%   steady-state targets may not be hit if theta in steady state does not
%   turn out to be as required by the input asset valuations. But
%   conditional on that being the case, all inputs will be on target.

  % theta0 implied by the asset valuations
  theta0 = debtGdp/(debtGdp + capitalGdp);
  % consumption-gdp ratio implied
  consumptionGdp = 1-govSpendingGdp-investmentGdp;
  % some parameters implied by ratios of stuff to gdp
  a0 = invRate/investmentGdp;
  g0 = govSpendingGdp*a0;
  rho = (1-theta0)*consumptionGdp/capitalGdp;
  adjBondGrowth0 = -surplusGdp/debtGdp;
  qK0 = capitalGdp*a0;
  iota0 = invRate - (qK0-1)/phi;
end

