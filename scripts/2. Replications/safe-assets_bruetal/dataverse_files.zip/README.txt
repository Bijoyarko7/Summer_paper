####################################################################################
######## Replication Files for Brunnermeier, Merkel, Sannikov "Safe Assets" ########
####################################################################################
1. This directory contains the following matlab scripts. All results with the ex-
   ception of the maximum likelihood estimates for the risk process (which, in turn,
   are located in the folder "R codes for ML estimation") can be reproduced by
   running these scripts without worrying about the other files in the directory.

 - mainScript.m: Computes the baseline model solution, creates Figures 1 and 2,
   determines the moments in Table 2, and produces the numbers stated in the text
   in the last paragraph of Section 4.5 (excess return volatility with and without
   safe assets). 

 - mainScript_robustness1.m: Copy of mainScript.m, except that model parameters are
   set as in the robustness specification 1 "lower \alpha^a" (compare Appendix C.2)

 - mainScript_robustness2.m: Copy of mainScript.m, except that model parameters are
   set as in the robustness specification 2 "lower debt/GDP target" (compare Appendix
   C.2)

 - mainScript_robustness3.m: Copy of mainScript.m, except that model parameters are
   set as in the robustness specification 3 "matching cov(S/Y,Y)" (compare Appendix
   C.2)

 - dynamicLafferCurve.m: Determines the Laffer curve depicted in Figures 3 and 5
   (the latter is in the online Appendix). This script assumes the presence of
   other variables in the workspace that are defined in either mainScript.m or one
   of its robustness variants. Therefore, mainScript.m (or one of its variants) must
   be run _first_ before executing this script.
   NOTE: The output is saved to a mat file whose name is specified by the variable
   export_filename defined in line 11. Adjust this line to the correct filename as
   indicated in the subsequent comment if you run dynamicLafferCurve.m for one of
   the robustness specifications!

 - plotLafferCurve.m: Creates Figure 3. Requires the file lafferCurve_baseline.mat
   in the working directory. This file is already present in this directory but can
   be recreated with dynamicLafferCurve.m.

 - plotLafferCurveComparison.m: Creates Figure 5 (in Appendix C.2) that compares the
   Laffer curves for the various calibration specifications. This file requires the
   files lafferCurve_baseline.mat, lafferCurve_robustness1.mat, lafferCurve_robustness2.mat,
   and lafferCurve_robustness3.mat to be present in the working directory. All four
   files are already present but can be recreated with dynamicLafferCurve.m.

 - computeDataMoments.m: Computes the data moments for Table 2 defined in
   Appendix C.1.1.

 - importData.m: Imports data from excel files located in directory "data" and
   saves results into various "data_*.mat" data files for processing by computeDataMoments.m.
   NOTE: These mat files are already pre-populated. This file is merely here for a user
   to understand where they are coming from.

####################################################################################
2. This directory contains the following mat data files:

 - data_asset_pricing.mat: Contains asset pricing data, can be re-created by importData.m

 - data_capital_stock.mat: Contains capital stock data, can be re-created by importData.m

 - data_macro_aggregates.mat: Contains macro data, can be re-created by importData.m

 - data_risk_free_rate.mat: Contains data on risk-free rate, can be re-created by 
   importData.m

 - data_surpluses.mat: Contains data on primary surpluses and debt, can be re-created 
   by importData.m

 - lafferCurve_baseline.mat: Laffer curve data for Figure 3. Created by dynamicLafferCurve.m,
   used by plotLafferCurve.m and plotLafferCurveComparison.m.

 - lafferCurve_robustness1.mat: Laffer curve data for Figure 5. Created by dynamicLafferCurve.m,
   used by plotLafferCurveComparison.m.

 - lafferCurve_robustness2.mat: Laffer curve data for Figure 5. Created by dynamicLafferCurve.m,
   used by plotLafferCurveComparison.m.

 - lafferCurve_robustness3.mat: Laffer curve data for Figure 5. Created by dynamicLafferCurve.m,
   used by plotLafferCurveComparison.m.

####################################################################################
3. This directory contains the following matlab function files:

 - solveModelPde.m: Computes the model solution globally on a grid. The grid and
   model parameters are specified as function arguments. For a brief description
   of the solution approach, see Appendix B.4.

 - solveModelAdditionalPdes.m: Solves additional partial differential equations
   note solved by solveModelPde.m such as the decomposition of bond values into
   a cash flow and service flow component (as in Figure 2) and the model solution
   for a model variant without safe assets.

 - simulateModel.m: Simulates a solved model and computes moments.

 - computeMomentsFromParams.m: Convenience method that takes parameter inputs
   first calls solveModelPde to obtain a model solution and then simulateModel to
   compute moments.

 - preCalibration.m: Performs a parameter transformation that maps a set of
   steady-state target moments into a set of parameters. This does not represent
   a proper inversion of the function parameters -> moments because moments in the
   paper are computed based on stochastic simulations, but it represents an
   approximate inverse of a part of this mapping that has helped to calibrate the
   model by hand. This function is included for completeness and can safely be 
   ignored.

 - investmentTechnology.m: Encodes the \Phi(\iota) function.

 - linearParabolicPDE_timeStep.m: Utility method that performs a single time step
   in a second order linear parabolic PDE with one space dimension. This function
   is repeatedly called in solveModelPde.m and solveModelAdditionalPdes.m.

 - aux.pack.m / aux.unpack.m: Utility methods that make it more efficient to pack
   a set of variables into a struct array or retrieve variables from a struct array.

####################################################################################
4. This directory contains the following matlab class files:

 - finiteDifferentiator.m: Utility class to compute first- and second-order finite
   difference derivatives.

####################################################################################
5. This directory contains the following sub-directories:

 - data: Folder for excel files containing raw data and simple transformations.
   These data sources are imported by importData.m.

 - R codes for ML estimation: Contains codes for the maximum likelihood estimation
   of the idiosyncratic risk process as outlined in Appendix C.1.2 written in R.
   See the readme file in that folder for further details.
