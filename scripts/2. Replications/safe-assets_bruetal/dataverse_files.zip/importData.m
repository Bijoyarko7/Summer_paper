%% importData.m
% imports data from xls files and saves them into mat files that are used
% by script computeDataMoments.m
% NOTE: this script clears the workspace in each of its cells!

%#ok<*NASGU> (suppress warning)
%% import macro aggregates data
% imports macro data from "data/macro aggregates.xls"
clear;
datafile = 'data/macro aggregates.xls';
gdp = xlsread(datafile,'N31:N310');
consumption = xlsread(datafile,'O31:O310');
investment = xlsread(datafile,'P31:P310');
govSpending = xlsread(datafile,'Q31:Q310');
year = xlsread(datafile,'S31:S310'); 
quarter = xlsread(datafile,'T31:T310');
clear datafile;
save('data_macro_aggregates');

%% import capital stock data
% imports capital stock data from "data/capital stock data.xls"
clear;
datafile = 'data/capital stock data.xls';
capitalOutputRatio = xlsread(datafile,'E15:E84');
year = xlsread(datafile,'G15:G84');
clear datafile;
save('data_capital_stock');

%% import surplus and debt data
% imports surplus and debt data from "data/primary surpluses.xls"
clear;
datafile = 'data/primary surpluses.xls';
surplusGdpRatio = xlsread(datafile,'I30:I309');
debtGdpRatio = xlsread(datafile,'J30:J309');
year = xlsread(datafile,'L30:L309');
quarter = xlsread(datafile,'M30:M309');
clear datafile;
save('data_surpluses');

%% import asset pricing data
% imports asset pricing data (except risk-free rate) from "data/asset price data.xls"
clear;
datafile = 'data/asset price data.xls';
yield1Year = xlsread(datafile,'B17:B603');
yield5Year = xlsread(datafile,'C17:C603');
equityIdx = xlsread(datafile,'D17:D603');
debtValue = xlsread(datafile,'E17:E603');
year = xlsread(datafile,'G17:G603');
month = xlsread(datafile,'H17:H603');
clear datafile;
save('data_asset_pricing');

%% import risk-free rate data
% imports risk-free rate data from "data/risk-free rate data.xls"
% (not included in "asset price data.xls" because it was added in a later
% revision)
clear;
datafile = 'data/risk-free rate data.xls';
riskFreeRate = xlsread(datafile,'F28:F614');
year = xlsread(datafile,'H28:G614');
month = xlsread(datafile,'I28:H614');
clear datafile;
save('data_risk_free_rate');