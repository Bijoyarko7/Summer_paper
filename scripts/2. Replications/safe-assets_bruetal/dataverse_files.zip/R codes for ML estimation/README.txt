This directory contains R codes for MLE Estimation of the idiosyncratic risk process written by Nicolas Hommel.

File "master_clean.R" is the main script. Executing this script generates the parameter estimates as console outputs. 
The actual estimation algorithm can be found in "mle_cir.R".

The folder "data" contains the CIV time series as downloaded from https://bernardherskovic.com/data/