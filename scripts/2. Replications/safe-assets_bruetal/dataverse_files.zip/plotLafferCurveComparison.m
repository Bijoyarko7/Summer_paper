%% settings

importFiles = {'lafferCurve_baseline','lafferCurve_robustness1','lafferCurve_robustness2','lafferCurve_robustness3'};
specificationLabels = {'baseline', 'lower $\alpha^a$', 'lower debt/GDP target', 'matching $\mathrm{cov}(S/Y,Y)$'};

% descriptions and limits
xTicks = [0,0.05,0.1,0.15,0.2,0.25];
xTickLabels = {'0','5\%','10\%','15\%','20\%','25\%'};
yTicks = [0,0.005,0.01,0.015,0.02,0.025];
yTickLabels = {'0','0.5\%','1.0\%','1.5\%','2.0\%','2.5\%'};


%% create the plot
figure(5);
hold on;
for i=1:numel(importFiles)
  lafferCurveData = load(importFiles{i});
  plot(lafferCurveData.meanBubbleMining,lafferCurveData.meanDeficitOutputRatio,'LineWidth',2)
end
legend(specificationLabels,'Interpreter','latex');
xlim([xTicks(1),xTicks(end)]);
ylim([yTicks(1),yTicks(end)]);
xticks(xTicks);
yticks(yTicks);
xticklabels(xTickLabels);
yticklabels(yTickLabels);
xlabel('$E[\breve{\mu}^\mathcal{B}]$','Interpreter','latex');
ylabel('primary deficit/GDP ($E[-s/a]$)','Interpreter','latex');
ax = gca; %axes handle
ax.FontSize = 14;
ax.TickLabelInterpreter = 'latex';
ax.Box = 'on';


