*********************************************************************************************************
"Estimation and Inference of Impulse Responses by Local Projections" American Economic Review, March 2005
by
Oscar Jorda
U.C. Davis
One Shields Ave.
Davis, CA 95616

e-mail: ojorda@ucdavis.edu
URL: www.econ.ucdavis.edu/faculty/jorda
*********************************************************************************************************
Inventory of files:

evnew.csv
is_new.csv

irfs.g
irfs.src

irfsmc1.g
irfsmc1.src
EM_MC.doc

irfsmc2.g
irfsmc2.src
GARCH_MC.doc

th_isvar.g
**********************
Conventions:

- *.csv files: data files
- *.g files: main file for a particular task. A file with the same name but with a .src ending contains the library of routines used in the .g file.
- *.doc files: word files with more accurate descriptions of the monte carlos. 

**********************
Description:

- evnew.csv: contains the Evans and Marshal (1998) data used in the first set of Monte Carlos in the paper. Specific descriptions of the data can be found in the paper and in the programs. These data are use to illustrate how the basic programs work if you would like to estimate impulse responses for your own data.

- is_new.csv: contains the data for the empirical application in the paper. A complete description of these data is available in the paper.

- irfs.g/src: these files estimate impulse responses for generic datasets. The example provided uses the evnew.csv data, which is the data used in the Monte Carlos and can be directly compared to them. The program will display graphically the output only if you have a windows version of GAUSS. Impulse responses are calculated with a VAR, linear and cubic projections. The program also calculates the usual variance decompositions.

- irfsmc1.g/src: These files replicate the first set of Monte Carlo experiments.

- irfsmc2.g/src: These files replicate the second set of Monte Carlo experiments, except for the time-varying parameter, bayesian VAR. There are numerous files associated with the TVP-BVAR procedure and they are rather complex (they took several days to run). Also, some of the files were produced by my R.A., Massimiliano de Santis, for his own dissertation work. If you are nevertheless interested in obtaining them, send me an e-mail or send an e-mail directly to Massimiliano (mdesantis@ucdavis.edu) if you are only interested in the TVP-BVAR procedures.

th_isvar.g: These file requires two .prc files from Hansen's website: http://www.ssc.wisc.edu/~bhansen/progs/ecnmt_00.html. The file names are described inside the program and are: thr_het.prc and thr_est.prc. I have not included these file here since I did not produce them. The program does the threshold testing for the empirical example in the paper and for which the data is provided. Once the thresholds are determined, estimation of the impulse responses is easily done by appropriate modification of the irfs.g file.

************************
Endnote:
I am in the process of producing more efficient code that estimates all the impulse responses jointly and calculates the joint variance-covariance matrix described in the paper. I will try to post subsequent code as it becomes available in my website. Upcoming code will include sequential estimation for efficient impulse responses and code to estimate rational expectations models. Stay tuned.

There are no guarantees on the code and you can use it at your own risk. It is useful if you quote the source of the code if you will use it for published work.

I will be grateful if you report back to me any errors you find.












