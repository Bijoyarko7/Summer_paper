function varargout = unpack(inputStruct,varargin)
%UNPACK Universal unpacker function for structural arrays
%   less elegant than the universal packer, because one has to pass the
%   argument variable names explicitly
  nfields = nargin-1;
  for i=1:nfields
    varargout{i} = inputStruct.(varargin{i});
  end
end

